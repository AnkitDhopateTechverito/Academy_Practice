package com.tv.tdd;

import java.util.ArrayList;
import java.util.List;

public class Wallet {
    private Money balance;

    private Transaction history;
    private List<Transaction> transactions = new ArrayList<>();


    public Wallet(CurrencyType currencyType) {
        this.balance = new Money(currencyType, 0);
    }

    public Money balance() {
        return balance;
    }


    public void withdrawAmount(Money outward) {

        this.balance = balance.deduct(outward);

        this.history = new Transaction(outward, TransactionType.DEBIT, balance);
    }

    public Transaction depositAmount(Money inward) {
        this.balance = balance.add(inward);
        Transaction transaction = new Transaction(inward, TransactionType.CREDIT, balance);
        this.history = transaction;
        this.transactions.add(transaction);
        return transaction;
    }

    public Transaction getHistory() {
        return history;
    }

    public List<Transaction> transactions() {
        return transactions;
    }
}
