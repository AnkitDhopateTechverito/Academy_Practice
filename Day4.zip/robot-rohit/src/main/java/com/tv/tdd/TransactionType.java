package com.tv.tdd;

public enum TransactionType {
    CREDIT,DEBIT
}
